# gamedev-brighttides
Final project for Game Development class at Dalhousie University.
